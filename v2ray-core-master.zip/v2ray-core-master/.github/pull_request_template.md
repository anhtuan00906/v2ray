Please Move to https://github.com/v2fly/v2ray-core/pulls
