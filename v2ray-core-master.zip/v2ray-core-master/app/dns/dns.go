// Package dns is an implementation of core.DNS feature.
package dns

//go:generate go run v2ray.com/core/common/errors/errorgen
