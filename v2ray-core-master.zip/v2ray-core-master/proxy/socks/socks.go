// Package socks provides implements of Socks protocol 4, 4a and 5.
package socks

//go:generate go run v2ray.com/core/common/errors/errorgen
